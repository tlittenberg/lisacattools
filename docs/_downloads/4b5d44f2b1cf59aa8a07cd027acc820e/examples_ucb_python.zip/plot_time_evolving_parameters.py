"""
Connecting catalogs
===================

Locate a source in an updated catalog and compare parameters.
"""

#%%
# This example shows how to find a particular source after the catalog has been updated 
# based on the `parent` meta data, and produces a corner plot showing how the parameter
# estimation evolves with time.

import os
import pandas as pd
import numpy as np
from chainconsumer import ChainConsumer
import lisacattools.lisacattools as lisacat

#%%
# Start by loading the 03 month catalog and selecting a source to follow

old_file = 'cat7864320_v3/cat7864320_v3.h5'
old_path = os.path.split(old_file)[0]

# Read metadata from each catalog
old_meta = pd.read_hdf(old_file, key = 'metadata')
old_cat = pd.read_hdf(old_file, key='detections')

# pick a source, any source
old_source = 'LDC0027827268'
old_samples = lisacat.getChain(old_cat,old_source,old_path)

old_cat.loc[[old_source],['SNR','Frequency','Amplitude']]

#%%
# Load the 06 month catalog and find the current name for `old_source`
new_file = 'cat15728640_v2/cat15728640_v2.h5'
new_path = os.path.split(new_file)[0]

# Read metadata from each catalog
new_meta = pd.read_hdf(new_file, key = 'metadata')
new_cat = pd.read_hdf(new_file, key = 'detections')

# select source that lists sourceIdx as parent
new_cat = new_cat[(new_cat['parent']==old_source)]
new_source = new_cat.index.values[0]
new_samples = lisacat.getChain(new_cat,new_source, new_path)

new_cat.loc[[new_source],['parent','SNR','Frequency','Amplitude']]

#%%
# Plot the posteriors for the 03 and 06 months inferences for the source

c = ChainConsumer()

# Select which parameters to plot & format the axes labels
parameters = ['Frequency', 
              'Amplitude', 
              'Ecliptic Longitude', 
              'Ecliptic Latitude', 
              'Inclination'
             ]
parameter_labels = [
    r'$f_0\ [{\rm Hz}]$',
    r'$\mathcal{A}$',
    r'$\phi\ [{\rm rad}]$',
    r'$\theta\ [{\rm rad}]$',
    r'$\iota\ [{\rm rad}]$',
    ]



# add chains 
c.add_chain(old_samples[parameters].values,parameters=parameter_labels,cloud=True,name=old_source)
c.add_chain(new_samples[parameters].values,parameters=parameter_labels,cloud=True,name=new_source)

#plot!
c.configure(sigmas=[1, 2, 3],
            linestyles=["-", "--"],
            legend_color_text=False,
            legend_kwargs={"fontsize": 18})
fig = c.plotter.plot(figsize=1.5)


